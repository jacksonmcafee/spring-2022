#include "circle.h"
#include <iostream>

using namespace std;

void Circle::PrintData() {
    cout << "Radius is: " << radius << endl;
    cout << "Area is: " << area << endl;
    cout << "Perimeter is: " << perimeter << endl;
}
